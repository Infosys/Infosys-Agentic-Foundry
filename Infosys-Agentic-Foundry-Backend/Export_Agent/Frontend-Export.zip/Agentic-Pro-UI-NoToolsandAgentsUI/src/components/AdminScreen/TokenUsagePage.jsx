import React from "react";
import SubHeader from "../commonComponents/SubHeader";
import PageLayout from "../../iafComponents/GlobalComponents/PageLayout";
import TokenUsageTracking from "./TokenUsageTracking";

const TokenUsagePage = () => (
  <div className="pageContainer">
    <SubHeader
      heading="Token Usage"
      activeTab="token-usage"
      breadcrumbItems={null}
      showSearch={false}
      showPlusButton={false}
      showRefreshButton={false}
    />
    <PageLayout>
      <TokenUsageTracking />
    </PageLayout>
  </div>
);

export default TokenUsagePage;
