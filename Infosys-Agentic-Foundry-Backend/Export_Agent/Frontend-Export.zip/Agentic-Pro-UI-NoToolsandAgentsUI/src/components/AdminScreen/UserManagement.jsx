import React, { useState, useEffect, useCallback, useImperativeHandle, forwardRef } from "react";
import { APIs, roleOptions } from "../../constant";
import { getDepartmentFromToken, getRoleFromToken } from "../../utils/jwtUtils";
import useFetch from "../../Hooks/useAxios";
import { useMessage } from "../../Hooks/MessageContext";
import Toggle from "../commonComponents/Toggle";
import Loader from "../commonComponents/Loader";
import EmptyState from "../commonComponents/EmptyState";
import NewCommonDropdown from "../commonComponents/NewCommonDropdown";
import SVGIcons from "../../Icons/SVGIcons";
import styles from "./UserManagement.module.css";
import "../../iafComponents/GlobalComponents/DisplayCard/DisplayCard1.css";

/**
 * UserManagement Component
 * 
 * Card-based layout matching Tools/Servers/Agents pages.
 * Admin: Shows Active toggle (for logged-in department only)
 * SuperAdmin: Shows department dropdown (with "All" option) + Active toggle
 * 
 * Exposes renderDepartmentDropdown via ref for parent to render next to search
 */
const UserManagement = forwardRef(({ externalSearchTerm = "", onReady, includeSuperAdminRoleFilter = false }, ref) => {
  const loggedInDepartment = getDepartmentFromToken();
  const userRole = getRoleFromToken();
  const isSuperAdmin = userRole.toLowerCase() === "superadmin" || userRole.toLowerCase() === "super_admin";

  const PAGE_SIZE = 12;

  // State
  const [users, setUsers] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [selectedDepartment, setSelectedDepartment] = useState(isSuperAdmin ? "All" : loggedInDepartment);
  const [selectedRole, setSelectedRole] = useState("All");
  const [loading, setLoading] = useState(false);
  const [loadingDepartments, setLoadingDepartments] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalCount, setTotalCount] = useState(0);

  // Hooks
  const { fetchData, patchData } = useFetch();
  const { addMessage } = useMessage();

  /**
   * Fetch departments list from /departments/list (SuperAdmin only)
   */
  const fetchDepartments = useCallback(async () => {
    if (!isSuperAdmin) return;

    setLoadingDepartments(true);
    try {
      const response = await fetchData(APIs.GET_DEPARTMENTS_LIST);
      if (Array.isArray(response)) {
        setDepartments(response);
      } else if (response?.departments && Array.isArray(response.departments)) {
        setDepartments(response.departments);
      }
    } catch (error) {
      console.error("Failed to fetch departments:", error);
    } finally {
      setLoadingDepartments(false);
    }
  }, [isSuperAdmin, fetchData]);

  /**
   * Fetch users using search-paginated endpoint
   */
  const fetchUsers = useCallback(async () => {
    setLoading(true);
    try {
      const params = [];
      params.push(`page_number=${currentPage}`);
      params.push(`page_size=${PAGE_SIZE}`);

      if (isSuperAdmin && selectedDepartment && selectedDepartment !== "All") {
        params.push(`department=${encodeURIComponent(selectedDepartment)}`);
      }

      if (externalSearchTerm && externalSearchTerm.trim()) {
        params.push(`search_value=${encodeURIComponent(externalSearchTerm.trim())}`);
      }

      if (selectedRole && selectedRole !== "All") {
        params.push(`role=${encodeURIComponent(selectedRole)}`);
      }

      const endpoint = `${APIs.GET_DEPARTMENT_USERS_SEARCH_PAGINATED}?${params.join("&")}`;
      const response = await fetchData(endpoint);

      if (response?.users && Array.isArray(response.users)) {
        const parsed = response.users.flatMap((user) => {
          // Parse departments JSON strings to extract role & department info
          const deptEntries = (user.departments || []).map((d) => {
            try { return typeof d === "string" ? JSON.parse(d) : d; } catch { return null; }
          }).filter(Boolean);

          // Create one card per department entry
          if (deptEntries.length > 0) {
            const userRole = user.role || deptEntries[0]?.role || "User";
            return deptEntries.map((d) => ({
              ...user,
              user_name: user.username || user.user_name || "",
              department_name: d.department_name || "Global",
              role: userRole,
              is_active: d.is_active ?? (user.status === "Active"),
              _cardKey: `${user.email}_${d.department_name || "Global"}`,
            }));
          }

          return [{
            ...user,
            user_name: user.username || user.user_name || "",
            department_name: "Global",
            role: user.role || "User",
            is_active: user.status === "Active",
            _cardKey: `${user.email}_Global`,
          }];
        });
        setUsers(parsed);
        setTotalCount(response.total || response.count || parsed.length);
      } else {
        setUsers([]);
        setTotalCount(0);
      }
    } catch (error) {
      addMessage("Failed to fetch users", "error");
      setUsers([]);
      setTotalCount(0);
    } finally {
      setLoading(false);
    }
  }, [selectedDepartment, currentPage, externalSearchTerm, selectedRole, fetchData, addMessage]);

  // Fetch departments on mount for SuperAdmin
  useEffect(() => {
    if (isSuperAdmin) {
      fetchDepartments();
    }
  }, [isSuperAdmin, fetchDepartments]);

  // Reset page when search, department, or role changes
  useEffect(() => {
    setCurrentPage(1);
  }, [externalSearchTerm, selectedDepartment, selectedRole]);

  // Fetch users when dependencies change
  useEffect(() => {
    fetchUsers();
  }, [fetchUsers]);

  // Refresh user list when a registration request is approved
  useEffect(() => {
    const handleNotificationAction = (e) => {
      if (e.detail?.action === "approved") {
        fetchUsers();
      }
    };
    window.addEventListener("notificationAction", handleNotificationAction);
    return () => window.removeEventListener("notificationAction", handleNotificationAction);
  }, [fetchUsers]);

  /**
   * Handle Active toggle (department-level)
   * Sends: { email_id, is_active, global_is_active, department_name }
   */
  const handleActiveToggle = async (user) => {
    const newValue = !user.is_active;
    const cardKey = user._cardKey;

    // Optimistic update - only for this specific card
    setUsers(prevUsers =>
      prevUsers.map(u =>
        u._cardKey === cardKey ? { ...u, is_active: newValue } : u
      )
    );

    try {
      await patchData(APIs.SET_USER_ACTIVE_STATUS, {
        email_id: user.email,
        is_active: newValue,
        global_is_active: user.global_is_active,
        department_name: user.department_name || selectedDepartment || null
      });
      addMessage(`User ${newValue ? "activated" : "deactivated"} in ${user.department_name}`, "success");
    } catch (error) {
      // Revert on error - only for this specific card
      setUsers(prevUsers =>
        prevUsers.map(u =>
          u._cardKey === cardKey ? { ...u, is_active: !newValue } : u
        )
      );
      const errorMessage = error?.response?.data?.detail || error?.message || "Failed to update user status";
      addMessage(errorMessage, "error");
    }
  };

  /**
   * Get role badge class
   */
  const getRoleClass = (role) => {
    const roleLower = (role || "").toLowerCase();
    if (roleLower === "superadmin" || roleLower === "super_admin") return styles.roleSuperAdmin;
    if (roleLower === "admin") return styles.roleAdmin;
    if (roleLower === "developer") return styles.roleDeveloper;
    if (roleLower === "manager") return styles.roleManager;
    return styles.roleDefault;
  };

  const isSuperAdminRole = (role) => {
    const normalized = (role || "").toLowerCase().replace(/[\s_-]/g, "");
    return normalized === "superadmin";
  };

  /**
   * Get department name helper
   */
  const getDepartmentName = (dept) => {
    if (typeof dept === "string") return dept;
    return dept?.department_name || dept?.name || "";
  };

  /**
   * Transform departments to dropdown options format - include "All" for SuperAdmin
   */
  const departmentOptions = isSuperAdmin
    ? ["All", ...departments.map(dept => getDepartmentName(dept))]
    : departments.map(dept => getDepartmentName(dept));

  /**
   * Role filter options - hardcoded from constant, include "All" at the top.
   * Super Admin page only: include SuperAdmin so it can be filtered via the same users endpoint.
   */
  const roleFilterOptions = includeSuperAdminRoleFilter
    ? ["All", ...roleOptions, "SuperAdmin"]
    : ["All", ...roleOptions];

  /**
   * Pagination helpers
   */
  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  /**
   * Expose department dropdown render function to parent via ref
   */
  useImperativeHandle(ref, () => ({
    getDepartmentDropdown: () => {
      if (!isSuperAdmin) return null;
      return (
        <NewCommonDropdown
          options={departmentOptions}
          selected={selectedDepartment}
          onSelect={(value) => setSelectedDepartment(value)}
          placeholder="Select Department"
          showSearch={true}
          width="200px"
        />
      );
    },
    isSuperAdmin
  }), [isSuperAdmin, departmentOptions, selectedDepartment]);

  // Notify parent when component is ready (has mounted and ref is available)
  // Also notify when departments load so parent re-renders with dropdown
  useEffect(() => {
    if (onReady) {
      onReady();
    }
  }, [onReady, departmentOptions]);

  return (
    <div className={styles.container}>
      {/* Department Filter - SuperAdmin only */}
      {isSuperAdmin && (
        <div className={styles.departmentFilterRow}>
          <div className={styles.departmentFilterInner}>
            <span className={styles.departmentIcon}>
              <SVGIcons icon="folder" width={16} height={16} color="currentColor" />
            </span>
            <label className={styles.departmentLabel}>Department</label>
            <NewCommonDropdown
              options={departmentOptions}
              selected={selectedDepartment}
              onSelect={(value) => setSelectedDepartment(value)}
              placeholder="Select Department"
              showSearch={false}
              width="220px"
              maxWidth="280px"
              disabled={loadingDepartments}
            />
          </div>
          <div className={styles.departmentFilterInner}>
            <span className={styles.departmentIcon}>
              <SVGIcons icon="user" width={16} height={16} color="currentColor" />
            </span>
            <label className={styles.departmentLabel}>Role</label>
            <NewCommonDropdown
              options={roleFilterOptions}
              selected={selectedRole}
              onSelect={(value) => setSelectedRole(value)}
              placeholder="Select Role"
              showSearch={false}
              width="180px"
              maxWidth="220px"
            />
          </div>
          {selectedDepartment && (
            <span className={styles.departmentUserCount}>
              {totalCount} {totalCount === 1 ? "user" : "users"}
            </span>
          )}
        </div>
      )}

      {(loading || loadingDepartments) ? (
        <Loader />
      ) : users.length === 0 ? (
        <EmptyState
          message={externalSearchTerm ? "No users match your search" : "No users found in this department"}
          icon="fa-user"
        />
      ) : (
        <>
          <div className={`display-cards-grid ${styles.cardGrid}`}>
            {users.map((user) => (
              <div
                key={user._cardKey || user.email}
                className={`${styles.userCard} ${!user.is_active ? styles.cardInactive : ""}`}
              >
                {/* Card Header */}
                <div className={styles.cardHeader}>
                  <div className={styles.userInfo}>
                    <h4 className={styles.userName}>{user.user_name || user.username || "Unknown"}</h4>
                    <span className={styles.userEmail}>{user.email}</span>
                  </div>
                </div>

                {/* Card Footer with Role, Department, and Active toggle */}
                <div className={styles.cardFooter}>
                  <div className={styles.badgesWrapper}>
                    <span className={`${styles.roleTag} ${getRoleClass(user.role)}`}>
                      {user.role || "User"}
                    </span>
                    {user.department_name && (
                      <span className={styles.departmentTag}>
                        {user.department_name}
                      </span>
                    )}
                  </div>

                  {!isSuperAdminRole(user.role) && (
                    <div className={styles.togglesWrapper}>
                      <div className={styles.toggleGroup}>
                        <span className={styles.toggleLabel}>Active</span>
                        <Toggle
                          value={user.is_active}
                          onChange={() => handleActiveToggle(user)}
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Pagination Controls */}
          {totalCount > PAGE_SIZE && (
            <div className={styles.paginationControls}>
              <div className={styles.paginationInfo}>
                Showing {Math.min((currentPage - 1) * PAGE_SIZE + 1, totalCount)} to{" "}
                {Math.min(currentPage * PAGE_SIZE, totalCount)} of {totalCount}
              </div>
              <div className={styles.paginationButtons}>
                <button
                  onClick={() => setCurrentPage((p) => p - 1)}
                  disabled={currentPage === 1}
                  className={styles.paginationButton}
                >
                  Previous
                </button>
                {(() => {
                  const pages = [];
                  const maxVisible = 5;
                  const halfVisible = Math.floor(maxVisible / 2);
                  let startPage = Math.max(1, currentPage - halfVisible);
                  const endPage = Math.min(totalPages, startPage + maxVisible - 1);
                  if (endPage - startPage < maxVisible - 1) {
                    startPage = Math.max(1, endPage - maxVisible + 1);
                  }
                  for (let i = startPage; i <= endPage; i++) {
                    pages.push(
                      <button
                        key={i}
                        onClick={() => setCurrentPage(i)}
                        className={`${styles.paginationButton} ${i === currentPage ? styles.paginationActive : ""}`}
                      >
                        {i}
                      </button>
                    );
                  }
                  return pages;
                })()}
                <button
                  onClick={() => setCurrentPage((p) => p + 1)}
                  disabled={currentPage === totalPages}
                  className={styles.paginationButton}
                >
                  Next
                </button>
              </div>
            </div>
          )}
        </>
      )}
    </div>
  );
});

export default UserManagement;
