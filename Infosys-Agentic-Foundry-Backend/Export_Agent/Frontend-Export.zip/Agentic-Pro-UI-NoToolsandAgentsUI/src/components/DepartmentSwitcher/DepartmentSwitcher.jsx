import { useState, useEffect, useRef } from "react";
import useFetch from "../../Hooks/useAxios";
import { useAuth } from "../../context/AuthContext";
import { APIs } from "../../constant";
import useErrorHandler from "../../Hooks/useErrorHandler";
import SVGIcons from "../../Icons/SVGIcons";
import { getJwtToken } from "../../Hooks/useAxios";
import authStorage from "../../utils/authStorage";
import "./departmentSwitcher.css";

function DepartmentSwitcher({ wrapperClassName = "" }) {
  const { fetchData, postData, setJwtToken, setRefreshToken } = useFetch();
  const { department, role, login, isAuthenticated } = useAuth();
  const { handleApiError } = useErrorHandler();

  const [departments, setDepartments] = useState([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [isSwitching, setIsSwitching] = useState(false);
  const dropdownRef = useRef(null);
  const hasLoadedRef = useRef(false);
  const retryCountRef = useRef(0);
  const maxRetries = 3;
  const retryDelay = 10000; // 10 seconds fixed delay

  // Load departments on mount - with retry mechanism
  useEffect(() => {
    // Only load if authenticated and haven't loaded yet
    if (!isAuthenticated || hasLoadedRef.current) {
      setIsLoading(false);
      return;
    }

    // Small delay to ensure JWT token is propagated to axios instance
    const timer = setTimeout(() => {
      const token = getJwtToken();
      if (token) {
        hasLoadedRef.current = true;
        retryCountRef.current = 0; // Reset retry count on success
        loadDepartments();
      } else {
        console.warn(`DepartmentSwitcher: No JWT token found (attempt ${retryCountRef.current + 1}/${maxRetries})`);

        // Retry with fixed 10-second delay if under max retries
        if (retryCountRef.current < maxRetries) {
          retryCountRef.current++;

          setTimeout(() => {
            const retryToken = getJwtToken();
            if (retryToken) {
              hasLoadedRef.current = true;
              retryCountRef.current = 0;
              loadDepartments();
            } else {
              console.warn(`Retry ${retryCountRef.current}/${maxRetries} failed - no JWT token`);
              if (retryCountRef.current >= maxRetries) {
                console.error("Max retries reached, giving up on department load");
                setIsLoading(false);
              }
            }
          }, retryDelay);
        } else {
          setIsLoading(false);
        }
      }
    }, 200); // Initial 200ms delay

    return () => clearTimeout(timer);
  }, [isAuthenticated]);

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [isOpen]);

  // Close dropdown when nav collapses (mouse leaves nav area)
  useEffect(() => {
    const navEl = document.querySelector("[data-nav]");
    if (!navEl) return;

    const handleNavMouseLeave = () => {
      setIsOpen(false);
    };

    navEl.addEventListener("mouseleave", handleNavMouseLeave);
    return () => navEl.removeEventListener("mouseleave", handleNavMouseLeave);
  }, []);

  const loadDepartments = async () => {
    try {
      const response = await fetchData(APIs.MY_DEPARTMENTS);

      if (response && response.approval && response.departments) {
        setDepartments(response.departments);
      }
    } catch (error) {
      handleApiError(error, { context: "DepartmentSwitcher.loadDepartments" });
    } finally {
      setIsLoading(false);
    }
  };

  const handleSwitchDepartment = async (departmentName) => {
    if (departmentName === department) {
      setIsOpen(false);
      return;
    }

    setIsSwitching(true);

    try {
      const response = await postData(APIs.SWITCH_DEPARTMENT, {
        department_name: departmentName,
      });

      if (response && response.approval) {
        const isMsal = localStorage.getItem("auth_type") === "msal";

        // For non-MSAL flows the backend issues a new token; update it.
        // For MSAL the token/refresh_token fields are null — keep the existing MSAL token.
        if (!isMsal) {
          if (response.token) setJwtToken(response.token);
          if (response.refresh_token) setRefreshToken(response.refresh_token);
        }

        // Update auth context with new department and role from the response.
        // Never pass refresh_token to login() in MSAL mode.
        login({
          userName: authStorage.getUserName() || "",
          user_session: authStorage.getSession() || "",
          role: response.role,
          department_name: response.department_name,
          ...(!isMsal && { refresh_token: response.refresh_token }),
        });

        // Reload page to fetch new data for the department
        window.location.reload();
      }
    } catch (error) {
      handleApiError(error, { context: "DepartmentSwitcher.switchDepartment" });
      setIsSwitching(false);
    }
  };

  const hasMultipleDepartments = !isLoading && departments.length > 1;
  const displayDepartment = isLoading
    ? (department || "Loading departments...")
    : (department || departments[0]?.department_name || "Select Department");

  const switcherContent = hasMultipleDepartments ? (
    <div className="department-switcher" ref={dropdownRef}>
      <button
        className={`department-trigger ${isOpen ? "open" : ""}`}
        onClick={() => setIsOpen(!isOpen)}
        disabled={isSwitching}
        title="Department Switcher"
      >
        <span className="department-switcher-title">Department Switcher</span>
        <div className="department-label-row">
          <SVGIcons icon="building" width={16} height={16} fill="currentColor" />
          <span className="department-name">{displayDepartment}</span>
          {role && <span className="department-role">({role})</span>}
          <SVGIcons
            icon="chevron-down"
            width={12}
            height={12}
            fill="currentColor"
            className={`dropdown-arrow ${isOpen ? "rotate" : ""}`}
          />
        </div>
      </button>

      {isOpen && (
        <div className="department-dropdown-menu">
          {departments.map((dept) => (
            <button
              key={dept.department_name}
              className={`dropdown-item ${dept.department_name === department ? "active" : ""} ${!dept.is_active ? "disabled" : ""}`}
              onClick={() => dept.is_active && handleSwitchDepartment(dept.department_name)}
              disabled={!dept.is_active || isSwitching}
            >
              <div className="dropdown-item-content">
                <div className="dropdown-item-left">
                  {dept.department_name === department && (
                    <SVGIcons icon="check" width={14} height={14} fill="currentColor" />
                  )}
                  <span className="dropdown-item-name">{dept.department_name}</span>
                </div>
              </div>
              {dept.is_default && dept.department_name !== department && (
                <span className="dropdown-item-badge">Default</span>
              )}
              {!dept.is_active && (
                <span className="dropdown-item-badge inactive">Inactive</span>
              )}
            </button>
          ))}
        </div>
      )}

      {isSwitching && (
        <div className="switching-overlay">
          <div className="spinner"></div>
          <span>Switching department...</span>
        </div>
      )}
    </div>
  ) : (
    <div
      className={`department-label ${isLoading && !department ? "department-label-loading" : ""}`}
      title="Department Switcher"
    >
      <span className="department-switcher-title">Department Switcher</span>
      <div className="department-label-row">
        <SVGIcons icon="building" width={16} height={16} fill="currentColor" />
        <span className="department-name">{displayDepartment}</span>
        {!isLoading && role && <span className="department-role">({role})</span>}
      </div>
    </div>
  );

  return wrapperClassName ? (
    <div className={wrapperClassName}>{switcherContent}</div>
  ) : (
    switcherContent
  );
}

export default DepartmentSwitcher;