import React, { useState, useEffect } from "react";
import styles from "./ConnectionModal.module.css";
import SVGIcons from "../../Icons/SVGIcons";
import { useMessage } from "../../Hooks/MessageContext";
import Loader from "../commonComponents/Loader.jsx";
import IAFButton from "../../iafComponents/GlobalComponents/Buttons/Button.jsx";
import UploadBox from "../commonComponents/UploadBox.jsx";
import { Modal } from "../commonComponents/Modal";

const ConnectionModal = ({ database, onClose, onSubmit, isConnecting }) => {
  const [formData, setFormData] = useState({});
  const [showPassword, setShowPassword] = useState(false);
  const { addMessage } = useMessage();
  const [loading, setLoading] = useState(false);
  const [isDragging, setIsDragging] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  // Initialize form data based on database fields
  useEffect(() => {
    const initialData = {};
    database.fields.forEach((field) => {
      // Set default values for readonly fields
      initialData[field.name] = field.defaultValue || "";
    });
    setFormData(initialData);
  }, [database]);

  // Field-specific input restrictions for each field
  const getSanitizedValue = (name, value) => {
    switch (name) {
      case "connectionName":
        // return value.replace(/[^a-zA-Z0-9_\s()\-\[\]{}]/g, ""); // Remove all escapes for [ and ]
        return value.replace(/[^a-zA-Z0-9_\s()-{}[\]]/g, "");
      case "host":
        return value.replace(/[^a-zA-Z0-9.-]/g, "");
      case "port":
        return value.replace(/[^0-9]/g, "");
      case "username":
        return value.replace(/[^a-zA-Z]/g, "");
      case "password":
      case "user_pwd":
        return value.replace(/[^a-zA-Z0-9]/g, "");
      case "databaseName":
        return value.replace(/[^a-zA-Z0-9_]/g, "");
      default:
        return value;
    }
  };

  const handleInputChange = (e) => {
    const { name } = e.target;
    const value = getSanitizedValue(name, e.target.value);
    setFormData((prev) => ({
      ...prev,
      [name]: value,
      // If user types in databaseName, clear uploaded_file
      ...(isSqlite && name === "databaseName" && value ? { uploaded_file: null } : {}),
    }));
  };

  const handleFileInputChange = (e) => {
    const file = e.target.files[0];
    if (file && validateFile(file)) {
      setFormData((prev) => ({
        ...prev,
        uploaded_file: file,
        // If user uploads file, clear databaseName
        ...(isSqlite ? { databaseName: "" } : {}),
      }));
      setSuccessMessage("File uploaded successfully.");
    }
    e.target.value = "";
  };

  const handleRemoveFile = () => {
    setFormData((prev) => ({ ...prev, uploaded_file: null }));
    setSuccessMessage(""); // Clear the success message when file is removed
    const fileInput = document.getElementById("sqlite_uploaded_file");
    if (fileInput) fileInput.value = "";
  };

  const handleDragEnter = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (!isDragging) setIsDragging(true);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const file = e.dataTransfer.files[0];
      if (validateFile(file)) {
        setFormData((prev) => ({ ...prev, uploaded_file: file }));
        setSuccessMessage("File uploaded successfully.");
      }
    }
  };

  const validateFile = (file) => {
    if (!file) return false;
    const validExtensions = [".db", ".sqlite", ".sqlite3"];
    const fileName = file.name.toLowerCase();
    const isValidExtension = validExtensions.some((ext) => fileName.endsWith(ext));
    if (!isValidExtension) {
      setErrorMessage("Invalid file format. Please upload a .db, .sqlite, or .sqlite3 file.");
      return false;
    }
    const maxSize = 200 * 1024 * 1024; // 200MB
    if (file.size > maxSize) {
      setErrorMessage("File size exceeds 200MB limit.");
      return false;
    }
    setErrorMessage("");
    return true;
  };

  // Helper: check if either path or file is filled for SQLite
  const isSqlite = database.id === "sqlite";
  const hasDbPath = isSqlite && formData.databaseName && formData.databaseName.trim() !== "";
  const hasDbFile = isSqlite && formData.uploaded_file;

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Defensive: For SQLite, only validate one of the two: path or file
    let requiredFields;
    if (isSqlite) {
      if (!hasDbPath && !hasDbFile) {
        addMessage("Please provide either a filename or upload a file for SQLite.", "error");
        return;
      }
      if (hasDbPath && hasDbFile) {
        addMessage("Please provide only one: filename or file upload for SQLite.", "error");
        return;
      }
      // Only require connectionName and databaseType for SQLite
      requiredFields = database.fields.filter((field) => ["connectionName", "databaseType"].includes(field.name));
      const missingFields = requiredFields.filter((field) => !formData[field.name]);
      if (missingFields.length > 0) {
        addMessage(`Please fill in required fields: ${missingFields.map((f) => f.label).join(", ")}`, "error");
        return;
      }
    } else {
      requiredFields = database.fields.filter((field) => field.required);
      const missingFields = requiredFields.filter((field) => !formData[field.name]);
      if (missingFields.length > 0) {
        addMessage(`Please fill in required fields: ${missingFields.map((f) => f.label).join(", ")}`, "error");
        return;
      }
    }
    setLoading(true);
    // Create a synthetic event object that mimics the form submission
    const syntheticEvent = {
      preventDefault: () => { },
      target: {
        elements: Object.keys(formData).reduce((acc, key) => {
          acc[key] = { value: formData[key] };
          return acc;
        }, {}),
      },
    };

    // Call the passed onSubmit function with the form data
    if (onSubmit) {
      const connectionData = {
        connectionName: formData.connectionName,
        databaseType: formData.databaseType,
        host: "",
        port: "",
        username: "",
        // For SQLite, only include the selected one
        ...(isSqlite && hasDbPath ? { databaseName: formData.databaseName } : {}),
        ...(isSqlite && hasDbFile ? { uploaded_file: formData.uploaded_file } : {}),
      };
      if (formData.databaseType.toLowerCase() !== "sqlite") {
        connectionData.host = formData.host;
        connectionData.port = formData.port;
        connectionData.username = formData.username;
        // Only include pwd if it's provided by the user
        if (formData["user_pwd"] && formData["user_pwd"].trim() !== "") {
          connectionData["user_pwd"] = formData["user_pwd"];
        }
        connectionData.databaseName = formData.databaseName;
      }
      window.tempConnectionData = connectionData;
      try {
        await onSubmit(syntheticEvent);
        setLoading(false);
        onClose(); // Close modal on success
      } catch (error) {
        setLoading(false);
      }
    }
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  // Helper: check if all required fields are filled and displayed
  const areAllRequiredFieldsFilled = (() => {
    if (isSqlite) {
      // For SQLite, require either databaseName or uploaded_file, not both, and required fields
      if (!hasDbPath && !hasDbFile) return false;
      if (hasDbPath && hasDbFile) return false;
      // Only require connectionName and databaseType for SQLite
      const requiredFields = database.fields.filter((field) => ["connectionName", "databaseType"].includes(field.name));
      return requiredFields.every((field) => formData[field.name]);
    } else {
      const requiredFields = database.fields.filter((field) => field.required);
      return requiredFields.every((field) => formData[field.name]);
    }
  })();

  return (
    <Modal
      isOpen={true}
      onClose={onClose}
      size="md"
      ariaLabel={`Connect to ${database.name}`}
      className={styles.connectionModal}
      showCloseButton={false}
    >
      <div className={styles.modalHeader}>
        <div className={styles.modalTitle}>
          <div className={styles.modalIcon} style={{ backgroundColor: database.color }}>
            <SVGIcons icon={database.icon} width={24} height={24} fill="white" />
          </div>
          <div>
            <h2>Connect to {database.name}</h2>
            <p>{database.description}</p>
          </div>
        </div>
        <button className="closeBtn" aria-label="Close modal" onClick={onClose}>
          ×
        </button>
      </div>

      <form className="form" onSubmit={handleSubmit}>
        {loading && <Loader />}
        <div className={styles.formBody}>
          {database.fields.map((field, index) => (
            <div key={field.name} className="formGroup">
              <label htmlFor={field.name} className="label-desc">
                {field.label}
                {field.required && <span className="required">*</span>}
              </label>

              {field.type === "password" ? (
                <div className={styles.passwordContainer}>
                  <input
                    id={field.name}
                    name={field.name}
                    type={showPassword ? "text" : "password"}
                    value={formData[field.name] || ""}
                    onChange={handleInputChange}
                    className="input"
                    required={field.required}
                  />
                  <button type="button" className={styles.passwordToggle} onClick={togglePasswordVisibility}>
                    <SVGIcons icon={showPassword ? "eye-slash" : "eye"} width={20} height={20} fill="var(--content-color, #666)" />
                  </button>
                </div>
              ) : field.name === "databaseName" && database.id === "sqlite" ? (
                <input
                  id={field.name}
                  name={field.name}
                  type={field.type}
                  value={formData[field.name] || ""}
                  onChange={handleInputChange}
                  className="input"
                  required={field.required}
                  readOnly={field.readOnly}
                  disabled={Boolean(formData.uploaded_file)}
                />
              ) : (
                <input
                  id={field.name}
                  name={field.name}
                  type={field.type}
                  value={formData[field.name] || ""}
                  onChange={handleInputChange}
                  className="input"
                  required={field.required}
                  readOnly={field.readOnly}
                />
              )}
            </div>
          ))}

          {/* SQLite warning and upload section - full width */}
          {database.id === "sqlite" && (
            <>
              <div className={styles.fullWidth}>
                <div className={styles.warningMessage}>Please upload a file or enter a new file name.</div>
              </div>

              <div className={styles.fullWidth}>
                <input
                  type="file"
                  id="sqlite_uploaded_file"
                  name="uploaded_file"
                  onChange={handleFileInputChange}
                  accept=".db,.sqlite,.sqlite3"
                  style={{ display: "none" }}
                />
                <UploadBox
                  file={formData.uploaded_file || null}
                  isDragging={isDragging}
                  onDragEnter={handleDragEnter}
                  onDragLeave={handleDragLeave}
                  onDragOver={handleDragOver}
                  onDrop={hasDbPath ? null : handleDrop}
                  onClick={() => !hasDbPath && document.getElementById("sqlite_uploaded_file").click()}
                  onRemoveFile={handleRemoveFile}
                  fileInputId="sqlite_uploaded_file"
                  acceptedFileTypes=".db,.sqlite,.sqlite3"
                  supportedText="Supported Extensions: db, sqlite, sqlite3"
                  dragText="Drop file here"
                  uploadText="Click to upload"
                  dragDropText=" or drag and drop"
                  disabled={hasDbPath}
                />
                {errorMessage && <div className={styles.errorMessage}>{errorMessage}</div>}
                {successMessage && !errorMessage && <div className={styles.successMessage}>{successMessage}</div>}
              </div>
            </>
          )}
        </div>

        <div className={styles.modalFooter}>
          <IAFButton type="secondary" onClick={onClose} disabled={isConnecting}>
            Cancel
          </IAFButton>
          <IAFButton type="primary" onClick={handleSubmit} disabled={isConnecting || !areAllRequiredFieldsFilled} icon={<SVGIcons icon="plug" width={16} height={16} fill="currentColor" />}>
            Connect
          </IAFButton>
        </div>
      </form>
    </Modal>
  );
};

export default ConnectionModal;
