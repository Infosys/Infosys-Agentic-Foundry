import { axiosInstance } from "../Hooks/useAxios";

const parseApiDetail = (detail) => {
  if (!detail) return null;
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    return detail
      .map((item) => (typeof item === "string" ? item : item?.msg || item?.message))
      .filter(Boolean)
      .join("; ");
  }
  if (typeof detail === "object" && (detail.message || detail.msg)) {
    return detail.message || detail.msg;
  }
  return null;
};

export const getMsalAuthErrorMessage = (error) => {
  if (!error) return "Microsoft sign-in failed. Please try again.";
  if (typeof error === "string") return error;
  if (error.message) return error.message;
  return "Microsoft sign-in failed. Please try again.";
};

const AUTH_ME_SUCCESS_STATUSES = new Set([
  "USER_EXISTS",
  "NEEDS_DEPARTMENT_SELECTION",
  "PENDING_APPROVAL",
]);

/** Provisioning statuses that complete MSAL login (not error screens). */
export const isAuthMeSuccessStatus = (status) =>
  AUTH_ME_SUCCESS_STATUSES.has((status || "").toUpperCase());

/** Error text from a 200 /auth/me body when status is ERROR or another failure state. */
export const getAuthMeResponseErrorMessage = (me, fallback = "Microsoft sign-in failed. Please try again.") => {
  if (me?.message && String(me.message).trim()) {
    return String(me.message).trim();
  }
  return fallback;
};

/**
 * Calls GET /auth/me with the MSAL access token to determine the user's
 * provisioning state. Called once per login in MsalAuthCallback.
 *
 * @param {string} accessToken - MSAL access token
 * @returns {Promise<{email, username, status, message}>}
 */
export async function checkUserStatus(accessToken) {
  try {
    const res = await axiosInstance.get("/auth/me", {
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });
    return res.data;
  } catch (err) {
    const errData = err?.response?.data || {};
    throw new Error(
      parseApiDetail(errData.detail) || errData.message || err.message || `HTTP ${err?.response?.status || "error"}`
    );
  }
}
