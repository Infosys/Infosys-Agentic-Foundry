const STRUCTURED_PARSE_FALLBACK_PREFIX =
  /^I couldn't format the response correctly, but here is the raw answer:\s*/i;

/**
 * Strips the backend fallback wrapper emitted when structured LLM parsing fails.
 * @param {string} content
 * @returns {string}
 */
export const unwrapStructuredParseFallback = (content) => {
  if (typeof content !== "string" || !content.trim()) return content || "";
  return content.replace(STRUCTURED_PARSE_FALLBACK_PREFIX, "").trim();
};

/**
 * Returns true when parts carry metadata indicating structured parse failure.
 * @param {Array} parts
 * @returns {boolean}
 */
export const hasStructuredParseError = (parts) => {
  if (!Array.isArray(parts)) return false;
  return parts.some((part) =>
    /Failed to parse structured response/i.test(String(part?.metadata?.error || "")),
  );
};

/**
 * Sanitize parts array by unwrapping fallback text content.
 * @param {Array} parts
 * @returns {Array}
 */
export const sanitizeResponseParts = (parts) => {
  if (!Array.isArray(parts)) return [];
  return parts.map((part) => {
    if (part?.type === "text" && typeof part?.data?.content === "string") {
      return {
        ...part,
        data: {
          ...part.data,
          content: unwrapStructuredParseFallback(part.data.content),
        },
      };
    }
    if (typeof part?.text === "string") {
      return { ...part, text: unwrapStructuredParseFallback(part.text) };
    }
    if (typeof part?.content === "string") {
      return { ...part, content: unwrapStructuredParseFallback(part.content) };
    }
    return part;
  });
};

/**
 * Resolve the best bot message text from an executor_message, preferring canonical
 * fields over parts and stripping structured-parse fallback wrappers.
 * @param {object} item
 * @param {object} [chatHistory]
 * @returns {string}
 */
export const resolveBotMessageText = (item, chatHistory = null) => {
  const canonical =
    safeStringifyMessage(item?.final_response) ||
    safeStringifyMessage(item?.response) ||
    safeStringifyMessage(item?.message) ||
    safeStringifyMessage(item?.content) ||
    safeStringifyMessage(chatHistory?.response) ||
    "";

  if (canonical.trim()) {
    return unwrapStructuredParseFallback(canonical);
  }

  const rawParts = item?.parts?.length ? item.parts : chatHistory?.parts;
  if (Array.isArray(rawParts) && rawParts.length > 0) {
    const partsText = rawParts
      .map(
        (p) =>
          safeStringifyMessage(p?.data?.content) ||
          safeStringifyMessage(p?.text) ||
          safeStringifyMessage(p?.content),
      )
      .filter(Boolean)
      .join("\n\n");
    if (partsText.trim()) {
      return unwrapStructuredParseFallback(partsText);
    }
  }

  return "";
};

/**
 * Resolve parts for display, falling back to chat-level parts on the last message.
 * @param {object} item
 * @param {object} chatHistory
 * @param {boolean} isLastMessage
 * @returns {Array}
 */
export const resolveResponseParts = (item, chatHistory, isLastMessage = false) => {
  const sourceParts =
    (Array.isArray(item?.parts) && item.parts.length > 0
      ? item.parts
      : isLastMessage && Array.isArray(chatHistory?.parts)
        ? chatHistory.parts
        : []) || [];
  return sanitizeResponseParts(sourceParts);
};

/**
 * Safely converts a bot-message value to a plain string.
 *
 * Handles all shapes returned across agent types:
 *  - string  → trimmed as-is
 *  - { response: "..." }  → unwrap (hybrid agent)
 *  - { message: "..." }   → unwrap
 *  - { answer:  "..." }   → unwrap
 *  - { content: "..." }   → unwrap
 *  - array   → join elements
 *  - other object → JSON.stringify fallback
 *  - null/undefined → ""
 *
 * @param {*} value
 * @returns {string}
 */
export const safeStringifyMessage = (value) => {
  if (value === null || value === undefined) {
    return "";
  }
  if (typeof value === "string") {
    return value.trim();
  }
  if (Array.isArray(value)) {
    return value
      .map((item) => (typeof item === "string" ? item : JSON.stringify(item)))
      .filter(Boolean)
      .join("\n")
      .trim();
  }
  if (typeof value === "object") {
    // Unwrap common single-key wrapper objects returned by various agent backends.
    // Priority order matches the canonical field names used in converToChatFormat.
    if (typeof value.response === "string" && value.response.trim()) {
      return value.response.trim();
    }
    if (typeof value.message === "string" && value.message.trim()) {
      return value.message.trim();
    }
    if (typeof value.answer === "string" && value.answer.trim()) {
      return value.answer.trim();
    }
    if (typeof value.content === "string" && value.content.trim()) {
      return value.content.trim();
    }
    try {
      return JSON.stringify(value, null, 2);
    } catch {
      return "";
    }
  }
  return String(value).trim();
};


/**
 * Extract a single- or double-quoted repr field value from a Python __repr__ string.
 * @param {string} str
 * @param {string} fieldName
 * @returns {string|null}
 */
const extractReprField = (str, fieldName) => {
  const marker = `${fieldName}=`;
  const idx = str.indexOf(marker);
  if (idx === -1) return null;

  let i = idx + marker.length;
  if (i >= str.length) return null;

  const quote = str[i];
  if (quote !== "'" && quote !== '"') return null;

  i += 1;
  let result = "";
  while (i < str.length) {
    const ch = str[i];
    if (ch === "\\" && i + 1 < str.length) {
      result += str[i + 1];
      i += 2;
      continue;
    }
    if (ch === quote) break;
    result += ch;
    i += 1;
  }

  return result;
};

/**
 * Convert a Python literal fragment (dict/list with single quotes) to a JS value.
 * @param {string} literal
 * @returns {*|null}
 */
const pythonLiteralToJson = (literal) => {
  try {
    const jsonish = literal
      .replace(/\bNone\b/g, "null")
      .replace(/\bTrue\b/g, "true")
      .replace(/\bFalse\b/g, "false")
      .replace(/'/g, '"');
    return JSON.parse(jsonish);
  } catch {
    return null;
  }
};

/**
 * Extract tool_calls=[...] from a Python __repr__ string.
 * @param {string} str
 * @returns {Array|null}
 */
const extractToolCallsFromRepr = (str) => {
  const marker = "tool_calls=[";
  const idx = str.indexOf(marker);
  if (idx === -1) return null;

  const start = idx + "tool_calls=".length;
  let depth = 0;
  for (let i = start; i < str.length; i += 1) {
    if (str[i] === "[") depth += 1;
    else if (str[i] === "]") {
      depth -= 1;
      if (depth === 0) {
        const arrayStr = str.slice(start, i + 1);
        const parsed = pythonLiteralToJson(arrayStr);
        if (!Array.isArray(parsed) || parsed.length === 0) return null;
        return parsed
          .map((tc) => ({
            id: tc.id,
            name: tc.name,
            args: tc.args ?? tc.arguments ?? {},
          }))
          .filter((tc) => tc.id && tc.name);
      }
    }
  }
  return null;
};

/**
 * Parse tool call arguments that may be JSON string or object.
 * @param {*} args
 * @returns {object}
 */
const parseToolArgs = (args) => {
  if (args && typeof args === "object") return args;
  if (typeof args === "string") {
    try {
      return JSON.parse(args);
    } catch {
      return {};
    }
  }
  return {};
};

/**
 * Normalize a tool call entry from sync or async backend shapes.
 * @param {object} tc
 * @returns {object|null}
 */
const normalizeToolCallEntry = (tc) => {
  if (!tc) return null;
  const name = tc.name || tc.function?.name || tc.tool_name || "";
  const id = tc.id || tc.tool_call_id || "";
  if (!name || !id) return null;
  return {
    id,
    name,
    args: parseToolArgs(tc.args ?? tc.arguments ?? tc.function?.arguments),
  };
};

/**
 * Parse one additional_details entry — structured object (sync) or Python repr string (async).
 * @param {string|object} detail
 * @returns {object|null}
 */
const parseDetailRepr = (detail) => {
  if (!detail) return null;

  if (typeof detail === "object" && !Array.isArray(detail)) {
    if (detail.role || (Array.isArray(detail.tool_calls) && detail.tool_calls.length > 0)) {
      return detail;
    }
    if (detail.type === "tool" || (detail.tool_call_id && detail.name)) {
      return {
        type: "tool",
        tool_call_id: detail.tool_call_id,
        content: safeStringifyMessage(detail.content),
        name: detail.name,
      };
    }
    if (Array.isArray(detail.tool_calls) && detail.tool_calls.length > 0) {
      const toolCalls = detail.tool_calls.map(normalizeToolCallEntry).filter(Boolean);
      return toolCalls.length > 0 ? { tool_calls: toolCalls } : null;
    }
    if (detail.additional_kwargs?.tool_calls?.length) {
      const toolCalls = detail.additional_kwargs.tool_calls
        .map(normalizeToolCallEntry)
        .filter(Boolean);
      return toolCalls.length > 0 ? { tool_calls: toolCalls } : null;
    }
    if (detail.role || detail.content !== undefined) {
      return {
        ...(detail.role ? { role: detail.role } : {}),
        content: safeStringifyMessage(detail.content),
        ...(detail.type ? { type: detail.type } : {}),
        ...(detail.tool_call_id ? { tool_call_id: detail.tool_call_id } : {}),
        ...(detail.name ? { name: detail.name } : {}),
      };
    }
    return detail;
  }

  if (typeof detail !== "string") return null;

  const trimmed = detail.trim();
  if (!trimmed.includes("content=") && !trimmed.includes("tool_calls=") && !trimmed.includes("tool_call_id=")) {
    return null;
  }

  const content = extractReprField(trimmed, "content") ?? "";
  const role = extractReprField(trimmed, "role");
  const name = extractReprField(trimmed, "name");
  const toolCallId = extractReprField(trimmed, "tool_call_id");
  const toolCalls = extractToolCallsFromRepr(trimmed);

  if (name && toolCallId) {
    return { type: "tool", tool_call_id: toolCallId, content, name };
  }

  if (toolCalls && toolCalls.length > 0) {
    return { tool_calls: toolCalls };
  }

  if (role) {
    return { role, content };
  }

  if (content.trim()) {
    if (trimmed.includes("tool_calls=[]") || trimmed.includes("invalid_tool_calls=[]")) {
      return { role: "assistant", content: unwrapStructuredParseFallback(content) };
    }
    return { content, type: "message" };
  }

  return null;
};

/**
 * Normalize additional_details to structured execution steps (sync + async parity).
 * @param {Array} details
 * @returns {Array<object>}
 */
export const normalizeAdditionalDetails = (details) => {
  if (!Array.isArray(details) || details.length === 0) return [];
  return details.map((detail) => parseDetailRepr(detail)).filter(Boolean);
};

/**
 * Count execution steps that will be rendered in the accordion (excludes nested tool outputs).
 * @param {Array} debugExecutor
 * @returns {number}
 */
export const countExecutionSteps = (debugExecutor) => {
  if (!Array.isArray(debugExecutor)) return 0;
  return debugExecutor.filter(
    (item) =>
      item?.role ||
      (Array.isArray(item?.tool_calls) && item.tool_calls.length > 0) ||
      (item?.content && item?.type !== "tool"),
  ).length;
};

/**
 * Normalize inference/chat response so async and sync payloads render identically.
 * @param {object} result
 * @returns {object}
 */
export const normalizeInferenceResult = (result) => {
  if (!result || typeof result !== "object") return result;

  const payload =
    result.result &&
    !Array.isArray(result.executor_messages) &&
    Array.isArray(result.result?.executor_messages)
      ? { ...result, ...result.result }
      : result;

  if (!Array.isArray(payload.executor_messages)) return payload;

  return {
    ...payload,
    executor_messages: payload.executor_messages.map((em) => ({
      ...em,
      additional_details: normalizeAdditionalDetails(em.additional_details),
    })),
  };
};

/**
 * Build a structured `debugExecutor` array (Execution Steps) for a single
 * executor_message. Prefers the backend-provided `additional_details` when
 * it is already structured. Falls back to synthesizing steps from the
 * canonical fields `user_query`, `tools_used`, and `final_response`.
 *
 * Output shape (consumed by AccordionPlanSteps):
 *   [
 *     { role: "user_query", content: "..." },
 *     { tool_calls: [{ id, name, args }] },
 *     { type: "tool", tool_call_id, content: "<output>" },
 *     { role: "assistant", content: "<final_response>" },
 *   ]
 *
 * @param {object} item - A single executor_messages[] entry
 * @returns {Array<object>} structured debug steps (never null)
 */
export const buildDebugExecutor = (item, chatHistory = null) => {
  if (!item || typeof item !== "object") return [];

  let steps = normalizeAdditionalDetails(item.additional_details);

  if (steps.length === 0) {
    steps = [];

    // 1. User query stage
    if (item.user_query && String(item.user_query).trim()) {
      steps.push({ role: "user_query", content: String(item.user_query) });
    }

    // 2. Tool calls + tool responses (from `tools_used` map)
    const toolsUsed =
      item.tools_used && typeof item.tools_used === "object" && !Array.isArray(item.tools_used)
        ? item.tools_used
        : null;

    if (toolsUsed) {
      const toolEntries = Object.entries(toolsUsed);
      const toolCalls = toolEntries
        .map(([callId, tu]) => {
          const name = tu?.name || tu?.tool_name || "";
          if (!name) return null;
          return {
            id: tu?.id || callId,
            name,
            args: tu?.args ?? tu?.arguments ?? {},
          };
        })
        .filter(Boolean);

      if (toolCalls.length > 0) {
        steps.push({ tool_calls: toolCalls });

        toolCalls.forEach((tc) => {
          const raw = toolsUsed[tc.id] || toolEntries.find(([, t]) => (t?.name || t?.tool_name) === tc.name)?.[1];
          const output = raw?.output ?? raw?.tool_output ?? "";
          steps.push({
            type: "tool",
            tool_call_id: tc.id,
            content: typeof output === "string" ? output : JSON.stringify(output, null, 2),
          });
        });
      }
    }

    // 3. Final assistant response
    const finalRes = item.final_response || item.response || item.message;
    if (typeof finalRes === "string" && finalRes.trim()) {
      steps.push({ role: "assistant", content: unwrapStructuredParseFallback(finalRes) });
    }
  } else {
    if (!steps.some((s) => s.role === "user_query") && item.user_query) {
      steps.unshift({ role: "user_query", content: String(item.user_query) });
    }
    if (
      !steps.some((s) => s.role === "assistant") &&
      (item.final_response || item.response || item.message)
    ) {
      const finalRes = item.final_response || item.response || item.message;
      steps.unshift({
        role: "assistant",
        content: unwrapStructuredParseFallback(safeStringifyMessage(finalRes)),
      });
    }
  }

  const hasEvaluatorStep = steps.some(
    (s) => s.role === "evaluator-response" || s.role === "evaluator-feedback",
  );
  const hasValidatorStep = steps.some(
    (s) => s.role === "validator-response" || s.role === "validator-feedback",
  );

  if (chatHistory?.evaluation_feedback && !hasEvaluatorStep) {
    steps.push({ role: "evaluator-feedback", content: chatHistory.evaluation_feedback });
  }
  if (chatHistory?.validation_feedback && !hasValidatorStep) {
    steps.push({ role: "validator-feedback", content: chatHistory.validation_feedback });
  }

  return steps;
};