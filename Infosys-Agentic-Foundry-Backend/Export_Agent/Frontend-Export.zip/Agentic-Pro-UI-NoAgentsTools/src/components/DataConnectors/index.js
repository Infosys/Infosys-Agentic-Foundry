import Database from './Database';

export default Database;